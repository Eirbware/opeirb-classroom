import website_builder as wb

page = wb.init_web_page()
wb.write_title(page, "Welcome to Pizzeirb")
wb.write_introduction(page, "Pizzeirb is a pizza service for the ENSEIRB-MATMECA")
order_list: list[wb.PizzaOrder] = [
    {
        "clientName": "Pepito",
        "phone": "+33111111111",
        "address": "Rue du Gras",
        "pizzas": {
            wb.PizzaItem("Margarita", "XL"): 3,
            wb.PizzaItem("Margarita", "L"): 1,
            wb.PizzaItem("Raclette", "S"): 1
        }
    },
    {
        "clientName": "Monsieur Olive",
        "phone": "+33222222222",
        "address": "Rue encore plus du Gras",
        "pizzas": {
            wb.PizzaItem("Napolitaine", "MDCCCI"): 0,
            wb.PizzaItem("Calzone", "XXL"): 2,
        }
    }
]
wb.write_order_list(page, order_list)
wb.export_page(page)
