from html import escape as __escape_html_tags
from functools import reduce
from typing import TypedDict, Callable, NamedTuple

def map_exec(func, iter):
    return list(map(func, iter))

def write_tag(content: str, tag:str, classes: list[str] = []):
    parsed_classes: str = f" class=\"{" ".join(classes)}\"" if len(classes) else ""
    return f"<{tag}{parsed_classes}>{content}</{tag}>"

def write_elementary_html(content: str, tag: str, classes: list[str] = []):
    return write_tag(__escape_html_tags(content), tag, classes)

def write_list(items: list[str], ordered: bool, classes: list[str] = []):
    def add_item_as_li(acc: str, item: str) -> str:
        return acc +  "\n" + write_tag(item, "li")

    parsed_items = reduce(add_item_as_li, items, "")
    return write_tag(parsed_items, "ol" if ordered else "ul", classes)

def write_table(headers: list[str], items: list[list[str]]):
    parsed_headers = write_tag(write_tag("\n".join(map_exec(
        lambda htitle: write_tag(htitle, "th"), headers
    )), "tr"), "thead")
    parsed_items = write_tag("\n".join(map_exec(lambda line: write_tag(
        "\n".join(map_exec(
        lambda item: write_tag(item, "td"), line
    )), "tr"), items)), "tbody")
    return write_tag(parsed_headers + "\n" + parsed_items, "table")

class PizzaItem(NamedTuple):
    """A tuple whose elements can be indexed with "pizzaName" and "pizzaSize"
    """
    pizzaName: str
    pizzaSize: str

class PizzaOrder(TypedDict):
    """Dictionnary with the fields related to a pizza order from a client"""
    clientName: str
    phone: str
    address: str
    pizzas: dict[PizzaItem, int] # the key is the pizza and the value is the quanity

class WebPage:
    """Abstract Data Type with the content of a web page. Edit your object
    through the given write_* functions.
    """
    def __init__(self):
        self.__title = ""
        self.__introduction = ""
        self.__pizza_list = ""

    def render_page(self) -> str:
        return write_tag(
            write_tag(self.__title + self.__introduction + self.__pizza_list,
                        "body")
            , "html")

    def write_page(self):
        page = self.render_page()
        with open("public/index.html", "w") as index_page:
            index_page.write(page)

    def write_introduction(self, txt: str):
        self.__introduction = write_elementary_html(txt, "p")

    def write_title(self, title: str):
        self.__title = write_elementary_html(title, "h1")
    
    def write_pizza_list(self, orderList: list[PizzaOrder]):
        def write_pizza_order(order: PizzaOrder) -> str:
            def convertor(elt: tuple[PizzaItem, int]):
                return list((elt[0].pizzaName, elt[0].pizzaSize, str(elt[1])))

            return write_list([
                write_elementary_html("Client name:", "u") + " " + write_elementary_html(order["clientName"], "b"),
                write_elementary_html("Phone:", "u") + " " + write_elementary_html(order["phone"], "b"),
                write_elementary_html("Address:", "u") + " " + write_elementary_html(order["address"], "b"),
                write_elementary_html("Ordered pizzas:", "u") + "\n" +  write_table(["Pizza Name", "Pizza Size", "quantity"],
                            map_exec(convertor, list(order["pizzas"].items())))
            ], False)
        self.__pizza_list = write_list(map_exec(write_pizza_order, orderList),
                                       True)

def init_web_page() -> WebPage:
    """Return a new empty web page."""
    return WebPage()

def write_title(webPage: WebPage, txt: str):
    """Write at the beginning of the web page the website title"""
    return webPage.write_title(txt)

def write_introduction(webPage: WebPage, txt: str):
    """Write at the beginning of the web page an presentation text."""
    return webPage.write_introduction(txt)

def write_order_list(webPage: WebPage, orders: list[PizzaOrder]):
    """Write in the web page the given pizza order list.
    """
    return webPage.write_pizza_list(orders)

def export_page(webPage: WebPage):
    """Publish the written web page for it to be rendered in the browser.

    In the background, the web page content is written in the
    `public/index.html` file and it can be rendered in the browser by running
    `make serve`
    """
    webPage.write_page()

def read_file(path: str) -> str:
    """Return the text in the file with the given absolute/relative path.
    """
    txt: str = ""
    with open(path, "r") as file:
        txt = file.read()
    return txt

